# Hello
## Let's try this
```java
try {
	int ans = 10/0;
	String name = null;
	System.out.println(name.length());
	int[] x = {10,20};
	System.out.println(x[3]);
	}
```
## Output
```console
Apple
Ball
Cat
Stream Closed
```