import java.io.*;
class Main{
	public static void main(String[] args){
	//variable declared and Initialized  
	int a = 10;
	System.out.println(a);
	}
}
