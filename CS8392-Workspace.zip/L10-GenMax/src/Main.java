import java.util.Arrays;

class GenMax <T>{
	T t;
	public GenMax(T t) {
		this.t = t;
	}
	public void sortTypes() {
		Arrays.sort(t);
	}
}
public class Main{
	public static void main(String[] args) {
		
	}
}