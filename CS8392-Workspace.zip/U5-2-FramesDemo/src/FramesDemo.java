import java.awt.*;
public class FramesDemo{
	public static void main(String[] args) {
		Frame f = new Frame();
		f.setSize(200, 200);
		f.setTitle("FramesDemo");
		f.setVisible(true);
	}
}