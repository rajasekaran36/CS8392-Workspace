import java.io.*;
public class Main{

    public static void main(String[] args) throws IOException{
		int[] a = new int[5];
		
		System.out.println("Number in 0 th position = "+a[0]);
		
    }
}