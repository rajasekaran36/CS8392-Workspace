import java.io.*;
class Main{
	public static void main(String[] args){
		int choice = 5;
		switch(choice){
			case 1:
				System.out.println("Case 1 matched");
			break;
			case 2:
				System.out.println("Case 2 matched");
			break;
			default:
				System.out.println("Case Default matched");
			break;
		}
	}
}