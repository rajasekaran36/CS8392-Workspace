import java.io.*;
class Main{
	public static void main(String[] args){
		int i = 0;
		
		/* Loop will exicute atlease once 
		 * Even i [current value is 0] is not greater than 10
		 */
		 
		do{
			System.out.println(i);
			i++;
		}while(i>20); //It checks for the condition at the end of loop.  
	}
}