import java.io.*;
class Main{
	public static void main(String[] args){
	//final variable  
	final int a = 10;
	System.out.println("Value of Final Variable a is "+a);
	}
}
