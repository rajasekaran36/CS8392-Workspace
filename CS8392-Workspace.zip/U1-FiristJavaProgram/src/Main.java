/*========================
 * @author Rajasekaran S
 * @version 1.0
 * Subject:Object Oriented Programming
 * Subject Code:CS8382
 * Concept: Say Hello World
 =========================*/
public class Main {

	public static void main(String[] args) {
		
		System.out.println("Hello World!!!!");

	}

}
