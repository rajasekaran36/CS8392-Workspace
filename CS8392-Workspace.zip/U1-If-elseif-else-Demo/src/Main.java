import java.io.*;
class Main{
	public static void main(String[] args){
		int a = 6;
		if(a==10){
			System.out.println("IF Block Exceuted");
	}	
		else if(a==6){
			System.out.println("ELSE IF Block Exceuted");
		}
		else{
			System.out.println("ELSE Block Exceuted");
		}
	}
}