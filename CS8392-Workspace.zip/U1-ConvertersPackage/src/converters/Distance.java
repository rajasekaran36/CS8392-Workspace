package converters;
public class Distance{
	public int toMeter(int kilometer){
		int meter = kilometer*1000;
		return meter;
	}
}
