package mainpack;
import converters.*;
class Main{
	public static void main(String[] args){
		Distance d = new Distance();
		System.out.println(d.toMeter(3));
	}
}
