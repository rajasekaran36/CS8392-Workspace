class Main {

	public static void main(String[] args) {
		
		int i;
		
		for(i=0;i<5;i++){
			if(i==3){
				System.out.println("Loop Terminated");
				break;
			}
			System.out.println(i);
		}
	}

}